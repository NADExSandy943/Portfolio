export const profile = {
  name: 'Sanidhya Vardhan Singh',
  role: 'Software Engineer',
  focus: 'Backend Systems, Data Engineering & Generative AI',
  location: 'Jammu, Jammu & Kashmir, India',
  email: 'sanidhyavardhansingh@gmail.com',
  phone: '8882529191',
  linkedin: 'https://linkedin.com/in/sanidhyavardhan-singh',
}

export const skills: Array<[string, string[]]> = [
  ['Languages', ['Python', 'SQL', 'Java', 'Go', 'C', 'C++', 'Rust']],
  ['AI & ML', ['Generative AI', 'Multi-Agent Systems', 'NLP', 'Computer Vision', 'TensorFlow', 'PyTorch', 'scikit-learn']],
  ['Data & Backend', ['REST API Design', 'Apache Kafka', 'Apache Spark', 'PostgreSQL', 'MongoDB', 'Redis']],
  ['Cloud & DevOps', ['AWS', 'Microsoft Azure', 'GCP', 'Docker', 'Kubernetes', 'CI/CD', 'Git']],
]

export const experience = [
  { period: 'May 2025 - Aug 2025', role: 'Backend Web Developer', company: 'G Caffe', place: 'Noida, India', points: ['Engineered scalable backend services for enterprise web applications using Python, Java, and optimized SQL schemas.', 'Implemented automated data processing and testing frameworks for high platform availability and zero-loss ingestion.', 'Integrated CI/CD pipelines for automated testing and containerized AWS deployments.'] },
  { period: 'Jun 2026', role: 'Corporate Job Simulation Participant', company: 'Deloitte via Forage', place: 'Remote', points: ['Performed network access control defense, system-log analysis, and threat-mitigation tasks.', 'Conducted forensic technology investigations and identified dataset anomalies.', 'Completed production-grade coding exercises focused on backend workflow optimization.'] },
  { period: 'Dec 2023', role: 'Website Developer', company: 'One Yes Info Tech Solutions', place: 'Chennai, India', points: ['Built metric-focused application features with scalable, minimalist architecture.', 'Integrated REST APIs and JSON data formats for high-throughput communication.', 'Reduced application latency by tuning database queries and using Redis caching.'] },
]

export const projects = [
  { name: 'AI-Driven Wildlife Deterrence', date: 'Dec 2024 - Feb 2025', tag: 'Computer Vision', description: 'An end-to-end distributed system that processes optical feeds and classifies wildlife patterns.', bullets: ['Python + TensorFlow computer vision pipeline', 'Concurrent sensor payload streaming with sub-second latency', 'Docker microservices deployed to Google Cloud Platform'], accent: 'violet' },
  { name: 'Distributed Systems Experiments', date: 'Present', tag: 'Systems', description: 'High-performance systems experiments exploring memory safety and transactional execution speed.', bullets: ['Go and Java systems experiments', 'Functional programming patterns', 'Open-source framework contributions'], accent: 'cyan' },
  { name: 'E-Vehicle Thermal Management', date: 'Engineering project', tag: 'Sustainability', description: 'A high-efficiency closed-loop liquid cooling solution for an electric vehicle powertrain.', bullets: ['Battery, motor, and inverter cooling', 'Thermodynamics modelling', 'Multi-point powertrain dependency mapping'], accent: 'orange' },
]

export const credentials = ['AI Fundamentals', 'Generative AI Development on Microsoft Foundry', 'Agentic AI & Multi-Agent Systems']
