import { motion, useMotionValue, useSpring } from 'framer-motion'
import { useEffect, useState } from 'react'

export default function DogCursor() {
  const x = useMotionValue(-100), y = useMotionValue(-100)
  const sx = useSpring(x, { stiffness: 100, damping: 15 }), sy = useSpring(y, { stiffness: 100, damping: 15 })
  const [moving, setMoving] = useState(false), [saluting, setSaluting] = useState(false)
  useEffect(() => {
    let timer: number
    const move = (event: PointerEvent) => { x.set(event.clientX - 26); y.set(event.clientY - 26); setMoving(true); window.clearTimeout(timer); timer = window.setTimeout(() => setMoving(false), 260) }
    const click = () => { setSaluting(true); window.setTimeout(() => setSaluting(false), 600) }
    window.addEventListener('pointermove', move); window.addEventListener('click', click)
    return () => { window.removeEventListener('pointermove', move); window.removeEventListener('click', click); window.clearTimeout(timer) }
  }, [x, y])
  return <motion.div className="dog-cursor" style={{ x: sx, y: sy }} aria-hidden="true">
    <motion.div className={`pup ${moving ? 'running' : 'sitting'} ${saluting ? 'saluting' : ''}`} animate={{ rotate: moving ? -8 : 0 }}>
      <i className="ear left"/><i className="ear right"/><i className="face"><b/><b/><em/></i><i className="body"><b className="paw one"/><b className="paw two"/><b className="tail"/></i>
    </motion.div>
  </motion.div>
}
